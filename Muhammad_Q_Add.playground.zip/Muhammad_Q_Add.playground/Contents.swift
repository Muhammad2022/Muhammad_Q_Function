let addition = {
    (val1: Int, val2: Int) -> Int in
    return val1 + val2
}

let result = addition(34, 54)
print (result)
